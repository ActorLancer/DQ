CREATE TABLE IF NOT EXISTS crosschain.gateway_identity (
  gateway_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gateway_name text NOT NULL,
  source_system text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  service_identity_id uuid REFERENCES core.service_identity(service_identity_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crosschain.cross_chain_request (
  ccr_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_chain_id text NOT NULL,
  target_chain_id text NOT NULL,
  request_type text NOT NULL,
  source_gateway_id uuid REFERENCES crosschain.gateway_identity(gateway_id),
  target_gateway_id uuid REFERENCES crosschain.gateway_identity(gateway_id),
  payload_hash text NOT NULL,
  nonce text NOT NULL,
  request_id text,
  ack_hash text,
  ack_status text,
  final_status text NOT NULL DEFAULT 'initiated',
  retry_count integer NOT NULL DEFAULT 0,
  terminate_flag boolean NOT NULL DEFAULT false,
  compensate_flag boolean NOT NULL DEFAULT false,
  timeout_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (source_chain_id, nonce)
);

CREATE TABLE IF NOT EXISTS crosschain.cross_chain_ack (
  ack_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ccr_id uuid NOT NULL REFERENCES crosschain.cross_chain_request(ccr_id) ON DELETE CASCADE,
  ack_hash text NOT NULL,
  ack_status text NOT NULL,
  payload_digest text,
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (ccr_id, ack_hash)
);

CREATE TABLE IF NOT EXISTS crosschain.witness_record (
  witness_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ccr_id uuid NOT NULL REFERENCES crosschain.cross_chain_request(ccr_id) ON DELETE CASCADE,
  service_identity_id uuid REFERENCES core.service_identity(service_identity_id),
  witness_type text NOT NULL,
  signature_digest text NOT NULL,
  witnessed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crosschain.request_status_history (
  request_status_history_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ccr_id uuid NOT NULL REFERENCES crosschain.cross_chain_request(ccr_id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  changed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crosschain.compensation_task (
  compensation_task_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ccr_id uuid NOT NULL REFERENCES crosschain.cross_chain_request(ccr_id) ON DELETE CASCADE,
  task_status text NOT NULL DEFAULT 'pending',
  task_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecosystem.partner (
  partner_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid REFERENCES core.organization(org_id) ON DELETE SET NULL,
  partner_name text NOT NULL,
  partner_type text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecosystem.connector_version (
  connector_version_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  connector_id uuid NOT NULL REFERENCES core.connector(connector_id) ON DELETE CASCADE,
  version text NOT NULL,
  compatibility_matrix jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecosystem.mutual_recognition (
  mutual_recognition_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id uuid NOT NULL REFERENCES ecosystem.partner(partner_id) ON DELETE CASCADE,
  recognition_type text NOT NULL,
  certificate_digest text,
  capability_scope jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  effective_from timestamptz,
  effective_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER trg_gateway_identity_updated_at BEFORE UPDATE ON crosschain.gateway_identity
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_cross_chain_request_updated_at BEFORE UPDATE ON crosschain.cross_chain_request
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_compensation_task_updated_at BEFORE UPDATE ON crosschain.compensation_task
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_partner_updated_at BEFORE UPDATE ON ecosystem.partner
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_mutual_recognition_updated_at BEFORE UPDATE ON ecosystem.mutual_recognition
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
