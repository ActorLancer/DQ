DELETE FROM authz.permission_definition WHERE stage_from = 'V3';
DELETE FROM authz.role_definition WHERE stage_from = 'V3';
