# 数据交易平台表关系总图 / ER 文本图

## 1. 说明

本文件基于以下输入统一整理：

- [正式PRD](/home/luna/Documents/DataB/正式PRD)
- [业务流程](/home/luna/Documents/DataB/业务流程)
- [页面说明书](/home/luna/Documents/DataB/页面说明书)
- [领域模型](/home/luna/Documents/DataB/领域模型)
- [用户角色说明](/home/luna/Documents/DataB/用户角色说明)
- [权限设计](/home/luna/Documents/DataB/权限设计)
- [数据库设计](/home/luna/Documents/DataB/数据库设计)
- [data_trading_blockchain_system_design_split](/home/luna/Documents/DataB/data_trading_blockchain_system_design_split)
- [原始PRD](/home/luna/Documents/DataB/原始PRD)

目标是给研发和 AI 提供一份可快速阅读的全量对象关系文本图。这里不是替代 SQL，而是把全局主干、版本增量和跨域关联集中描述出来。

## 2. 顶层域关系图

```text
core.organization
  ├─< core.department
  ├─< core.user_account
  ├─< core.application
  ├─< core.service_identity
  ├─< core.connector
  └─< core.execution_environment

authz.role_definition
  ├─< authz.role_permission >─ authz.permission_definition
  └─< authz.subject_role_binding >─ core.user_account / core.application / core.service_identity

catalog.data_asset
  ├─< catalog.asset_version
  ├─< catalog.asset_storage_binding
  ├─< catalog.asset_sample
  ├─< catalog.asset_structured_dataset
  │    └─< catalog.asset_structured_row
  └─< catalog.product
        ├─< catalog.product_tag >─ catalog.tag
        ├─< catalog.product_sku
        ├─< contract.template_binding >─ contract.template_definition
        └─< contract.policy_binding >─ contract.usage_policy

trade.inquiry
  └─< trade.order_main
        ├─< trade.order_line >─ catalog.product_sku
        ├─< trade.order_status_history
        ├─1 contract.digital_contract
        │    └─< contract.contract_signer
        ├─< trade.authorization_grant
        ├─< delivery.delivery_record
        │    ├─< delivery.delivery_ticket
        │    ├─< delivery.delivery_receipt
        │    ├─< delivery.key_envelope
        │    ├─< delivery.api_credential
        │    ├─< delivery.sandbox_workspace
        │    │    └─< delivery.sandbox_session
        │    └─< delivery.report_artifact
        ├─< billing.billing_event
        ├─< billing.settlement_record
        ├─< billing.refund_record
        ├─< billing.compensation_record
        ├─< support.dispute_case
        │    ├─< support.dispute_status_history
        │    ├─< support.evidence_object
        │    └─< support.decision_record
        ├─< review.review_task
        │    └─< review.review_step
        └─< ops.approval_ticket
             └─< ops.approval_step

billing.wallet_account
  ├─< billing.account_ledger_entry
  ├─< billing.escrow_ledger
  ├─< billing.deposit_record
  ├─< billing.penalty_event
  └─< billing.invoice_request

risk.rating_record
  ├─< risk.reputation_snapshot
  └─< risk.blacklist_entry

audit.audit_event
  └─< audit.evidence_package

ops.outbox_event
  └─< ops.dead_letter_event

search.product_search_document

developer.test_application
developer.test_wallet
developer.mock_provider_binding

chain.contract_event_projection
chain.chain_anchor
```

## 3. V1 业务主链路 ER 图

```text
Organization(卖方/买方/平台)
  ├─ Department
  ├─ UserAccount
  ├─ Application
  └─ WalletAccount

DataAsset
  ├─ AssetVersion
  ├─ AssetStorageBinding
  ├─ AssetSample
  └─ Product
       ├─ ProductTag
       ├─ ProductSku
       ├─ TemplateBinding
       └─ PolicyBinding

Inquiry
  └─ OrderMain
       ├─ OrderLine
       ├─ DigitalContract
       ├─ AuthorizationGrant
       ├─ DeliveryRecord
       ├─ BillingEvent
       ├─ SettlementRecord
       ├─ DisputeCase
       └─ ChainAnchor
```

## 4. V2 增量 ER 图

```text
catalog.product / catalog.product_sku
  └─ may reference model-oriented offerings

ml.model_asset
  ├─< ml.model_version
  ├─< ml.training_task
  │    ├─< ml.task_participant
  │    ├─< ml.training_round
  │    ├─< ml.model_update
  │    ├─< ml.proof_artifact
  │    └─< ml.task_status_history
  ├─< ml.compute_task
  │    ├─< ml.compute_result
  │    └─< ml.proof_artifact
  └─< search.model_search_document

ml.algorithm_artifact
  └─< ml.compute_task

billing.profit_share_rule
  ├─< billing.contribution_record
  ├─< billing.reward_record
  └─< billing.reward_pool

chain.public_anchor_batch
  └─< chain.credential_token
       └─< chain.credential_status_history
```

## 5. V3 增量 ER 图

```text
crosschain.gateway_identity
  └─< crosschain.cross_chain_request
       ├─< crosschain.cross_chain_ack
       ├─< crosschain.witness_record
       ├─< crosschain.request_status_history
       └─< crosschain.compensation_task

ecosystem.partner
  ├─< ecosystem.connector_version
  └─< ecosystem.mutual_recognition

risk.graph_node
  └─< risk.graph_edge

risk.risk_alert
  └─< risk.risk_case

risk.freeze_ticket
  └─< risk.governance_action_log

audit.regulator_query
  └─< audit.regulator_export_record
```

## 6. 分域详细对象关系

### 6.1 身份、组织与访问控制

```text
core.organization(id)
  ├─ core.department.organization_id
  ├─ core.user_account.organization_id
  ├─ core.application.organization_id
  ├─ core.service_identity.organization_id
  ├─ core.connector.organization_id
  └─ core.execution_environment.organization_id

core.department(id)
  ├─ self.parent_department_id
  ├─ core.user_account.department_id
  └─ authz.subject_role_binding.scope_department_id

core.user_account(id)
  ├─ core.did_binding.user_id
  ├─ contract.contract_signer.user_id
  ├─ authz.subject_role_binding.subject_id(type=user)
  ├─ developer.test_application.created_by
  └─ developer.test_wallet.created_by

core.application(id)
  ├─ delivery.api_credential.application_id
  ├─ authz.subject_role_binding.subject_id(type=application)
  └─ ml.compute_task.application_id

authz.role_definition(id)
  ├─ authz.role_permission.role_id
  └─ authz.subject_role_binding.role_id

authz.permission_definition(id)
  └─ authz.role_permission.permission_id
```

### 6.2 数据资产、商品与策略

```text
catalog.data_asset(id)
  ├─ catalog.asset_version.asset_id
  ├─ catalog.asset_storage_binding.asset_id
  ├─ catalog.asset_sample.asset_id
  ├─ catalog.asset_structured_dataset.asset_id
  └─ catalog.product.asset_id

catalog.asset_structured_dataset(id)
  └─ catalog.asset_structured_row.dataset_id

catalog.product(id)
  ├─ catalog.product_sku.product_id
  ├─ catalog.product_tag.product_id
  ├─ contract.template_binding.product_id
  ├─ contract.policy_binding.product_id
  ├─ trade.order_line.product_id
  ├─ review.review_task.product_id
  ├─ chain.chain_anchor.product_id
  ├─ search.product_search_document.product_id
  └─ billing.profit_share_rule.product_id

catalog.tag(id)
  └─ catalog.product_tag.tag_id

contract.template_definition(id)
  └─ contract.template_binding.template_id

contract.usage_policy(id)
  └─ contract.policy_binding.policy_id
```

### 6.3 交易、合同、交付

```text
trade.inquiry(id)
  └─ trade.order_main.inquiry_id

trade.order_main(id)
  ├─ trade.order_line.order_id
  ├─ trade.order_status_history.order_id
  ├─ contract.digital_contract.order_id
  ├─ trade.authorization_grant.order_id
  ├─ delivery.delivery_record.order_id
  ├─ billing.billing_event.order_id
  ├─ billing.settlement_record.order_id
  ├─ billing.refund_record.order_id
  ├─ billing.compensation_record.order_id
  ├─ support.dispute_case.order_id
  ├─ audit.audit_event.order_id
  ├─ chain.chain_anchor.order_id
  └─ ops.outbox_event.aggregate_id(order/order_main)

contract.digital_contract(id)
  ├─ contract.contract_signer.contract_id
  └─ trade.order_main.contract_id

delivery.storage_object(id)
  ├─ delivery.delivery_record.storage_object_id
  ├─ delivery.key_envelope.storage_object_id
  ├─ support.evidence_object.storage_object_id
  └─ audit.evidence_package.storage_object_id

delivery.delivery_record(id)
  ├─ delivery.delivery_ticket.delivery_id
  ├─ delivery.delivery_receipt.delivery_id
  ├─ delivery.key_envelope.delivery_id
  ├─ delivery.api_credential.delivery_id
  ├─ delivery.sandbox_workspace.delivery_id
  └─ delivery.report_artifact.delivery_id

delivery.sandbox_workspace(id)
  └─ delivery.sandbox_session.workspace_id
```

### 6.4 计费、托管、保证金、惩罚、奖励、分润

```text
billing.token_asset(id)
  ├─ billing.wallet_account.token_asset_id
  ├─ billing.account_ledger_entry.token_asset_id
  ├─ billing.escrow_ledger.token_asset_id
  ├─ billing.deposit_record.token_asset_id
  ├─ billing.reward_pool.token_asset_id
  └─ billing.reward_record.token_asset_id

billing.wallet_account(id)
  ├─ billing.account_ledger_entry.wallet_account_id
  ├─ billing.deposit_record.wallet_account_id
  └─ billing.invoice_request.wallet_account_id

trade.order_main(id)
  ├─ billing.billing_event.order_id
  ├─ billing.settlement_record.order_id
  ├─ billing.penalty_event.order_id
  ├─ billing.refund_record.order_id
  ├─ billing.compensation_record.order_id
  ├─ billing.escrow_ledger.order_id
  └─ billing.reward_record.order_id

billing.profit_share_rule(id)
  ├─ billing.contribution_record.rule_id
  ├─ billing.reward_record.rule_id
  └─ billing.reward_pool.rule_id
```

### 6.5 合规、审核、争议、风险

```text
review.review_task(id)
  ├─ review.review_step.review_task_id
  └─ ops.approval_ticket.review_task_id

ops.approval_ticket(id)
  └─ ops.approval_step.ticket_id

support.dispute_case(id)
  ├─ support.dispute_status_history.dispute_case_id
  ├─ support.evidence_object.dispute_case_id
  ├─ support.decision_record.dispute_case_id
  └─ ops.outbox_event.aggregate_id(dispute_case)

risk.rating_record(id)
  └─ risk.reputation_snapshot.rating_record_id

risk.risk_alert(id)
  └─ risk.risk_case.alert_id

risk.graph_node(id)
  ├─ risk.graph_edge.from_node_id
  └─ risk.graph_edge.to_node_id

risk.freeze_ticket(id)
  └─ risk.governance_action_log.freeze_ticket_id
```

### 6.6 审计、日志、开发者、链上

```text
audit.audit_event(id)
  ├─ audit.evidence_package.audit_event_id
  ├─ chain.contract_event_projection.audit_event_id
  ├─ chain.chain_anchor.audit_event_id
  └─ audit.regulator_export_record.audit_event_id

ops.outbox_event(id)
  ├─ ops.dead_letter_event.outbox_event_id
  ├─ chain.chain_anchor.outbox_event_id
  └─ crosschain.cross_chain_request.outbox_event_id

developer.test_application(id)
  ├─ developer.mock_provider_binding.test_application_id
  └─ delivery.api_credential.test_application_id

developer.test_wallet(id)
  ├─ billing.wallet_account.test_wallet_id
  └─ chain.credential_token.test_wallet_id
```

### 6.7 模型、训练、受控计算、证明

```text
ml.model_asset(id)
  ├─ ml.model_version.model_asset_id
  ├─ ml.training_task.model_asset_id
  ├─ ml.compute_task.model_asset_id
  └─ search.model_search_document.model_asset_id

ml.algorithm_artifact(id)
  └─ ml.compute_task.algorithm_artifact_id

ml.training_task(id)
  ├─ ml.task_participant.training_task_id
  ├─ ml.training_round.training_task_id
  ├─ ml.model_update.training_task_id
  ├─ ml.proof_artifact.training_task_id
  └─ ml.task_status_history.training_task_id

ml.compute_task(id)
  ├─ ml.compute_result.compute_task_id
  ├─ ml.proof_artifact.compute_task_id
  └─ ml.task_status_history.compute_task_id
```

### 6.8 跨链、生态互联、监管

```text
crosschain.gateway_identity(id)
  └─ crosschain.cross_chain_request.gateway_identity_id

crosschain.cross_chain_request(id)
  ├─ crosschain.cross_chain_ack.request_id
  ├─ crosschain.witness_record.request_id
  ├─ crosschain.request_status_history.request_id
  ├─ crosschain.compensation_task.request_id
  └─ audit.audit_event.cross_chain_request_id

ecosystem.partner(id)
  ├─ ecosystem.connector_version.partner_id
  └─ ecosystem.mutual_recognition.partner_id

audit.regulator_query(id)
  └─ audit.regulator_export_record.regulator_query_id
```

## 7. 版本增量与预埋关系

### 7.1 V1 必落主表

- 身份与权限：`core.*`、`authz.*`
- 商品与策略：`catalog.*`、`contract.template_*`、`contract.usage_policy`
- 交易链路：`trade.*`、`delivery.*`
- 账单与争议：`billing.*`、`support.*`
- 审核与审批：`review.*`、`ops.approval_*`
- 审计、搜索、开发者：`audit.*`、`search.product_search_document`、`developer.*`
- 链下主状态与联盟链锚定：`chain.contract_event_projection`、`chain.chain_anchor`

### 7.2 V1 预埋对象

- `core.connector`
- `core.execution_environment`
- `catalog.asset_structured_row.embedding`
- `search.product_search_document.embedding`

### 7.3 V2 增量对象

- `ml.*`
- `search.model_search_document`
- `billing.profit_share_rule`
- `billing.reward_pool`
- `billing.contribution_record`
- `billing.reward_record`
- `chain.public_anchor_batch`
- `chain.credential_token`
- `chain.credential_status_history`

### 7.4 V3 增量对象

- `crosschain.*`
- `ecosystem.*`
- `risk.risk_alert`
- `risk.risk_case`
- `risk.graph_node`
- `risk.graph_edge`
- `risk.freeze_ticket`
- `risk.governance_action_log`
- `audit.regulator_query`
- `audit.regulator_export_record`

## 8. 关键触发器与联动

```text
common.tg_set_updated_at
  -> all major tables

common.tg_order_status_history
  -> trade.order_main status update
  -> trade.order_status_history insert

common.tg_dispute_status_history
  -> support.dispute_case status update
  -> support.dispute_status_history insert

search.tg_refresh_product_search_document
  -> catalog.product insert/update
  -> search.product_search_document upsert

common.tg_write_outbox
  -> catalog.product / trade.order_main / support.dispute_case
  -> ops.outbox_event insert
```

## 9. 说明结论

这套 ER 文本图的目标不是把所有字段逐项搬运，而是把：

- 哪些对象是聚合根
- 哪些对象是明细/历史/投影
- 哪些关系跨版本扩展
- 哪些对象虽然 V1 暂不完整启用但必须预留

统一描述清楚。实际落地时，以 [数据库设计](/home/luna/Documents/DataB/数据库设计) 下的 SQL 迁移脚本为最终执行基线。
