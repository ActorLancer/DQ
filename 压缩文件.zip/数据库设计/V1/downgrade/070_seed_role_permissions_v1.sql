DELETE FROM authz.role_permission
WHERE role_key IN (
  'platform_super_admin','subject_reviewer','product_reviewer','compliance_reviewer',
  'risk_operator','finance_operator','dispute_operator','audit_admin','tenant_admin',
  'data_governance_admin','listing_manager','procurement_manager','finance_manager',
  'developer_admin','business_analyst','regulator_observer'
);
