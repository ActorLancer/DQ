CREATE TABLE IF NOT EXISTS billing.token_asset (
  token_code text PRIMARY KEY,
  token_name text NOT NULL,
  token_type text NOT NULL,
  decimals integer NOT NULL DEFAULT 8,
  chain_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO billing.token_asset (token_code, token_name, token_type, decimals)
VALUES
  ('CNY_SETTLEMENT', 'CNY Settlement Unit', 'fiat_virtual', 2),
  ('PLATFORM_STAKE', 'Platform Stake Unit', 'internal', 8)
ON CONFLICT (token_code) DO NOTHING;

CREATE TABLE IF NOT EXISTS billing.wallet_account (
  wallet_account_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  token_code text NOT NULL REFERENCES billing.token_asset(token_code),
  available_balance numeric(24, 8) NOT NULL DEFAULT 0,
  locked_balance numeric(24, 8) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (subject_type, subject_id, token_code)
);

CREATE TABLE IF NOT EXISTS billing.account_ledger_entry (
  account_ledger_entry_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_account_id uuid NOT NULL REFERENCES billing.wallet_account(wallet_account_id) ON DELETE CASCADE,
  entry_type text NOT NULL,
  direction text NOT NULL,
  reference_type text,
  reference_id uuid,
  amount numeric(24, 8) NOT NULL,
  available_after numeric(24, 8),
  locked_after numeric(24, 8),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.escrow_ledger (
  escrow_ledger_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  token_code text NOT NULL REFERENCES billing.token_asset(token_code),
  lock_amount numeric(24, 8) NOT NULL DEFAULT 0,
  buyer_deposit_amount numeric(24, 8) NOT NULL DEFAULT 0,
  seller_deposit_amount numeric(24, 8) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending_lock',
  locked_at timestamptz,
  released_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.deposit_record (
  deposit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  deposit_type text NOT NULL,
  token_code text NOT NULL REFERENCES billing.token_asset(token_code),
  amount numeric(24, 8) NOT NULL,
  status text NOT NULL DEFAULT 'pending_lock',
  wallet_account_id uuid REFERENCES billing.wallet_account(wallet_account_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.billing_event (
  billing_event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  event_type text NOT NULL,
  event_source text NOT NULL,
  amount numeric(24, 8) NOT NULL DEFAULT 0,
  currency_code text NOT NULL DEFAULT 'CNY',
  units numeric(24, 8),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS billing.settlement_record (
  settlement_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  settlement_type text NOT NULL,
  settlement_status text NOT NULL DEFAULT 'pending',
  payable_amount numeric(24, 8) NOT NULL DEFAULT 0,
  refund_amount numeric(24, 8) NOT NULL DEFAULT 0,
  compensation_amount numeric(24, 8) NOT NULL DEFAULT 0,
  reason_code text,
  settled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.penalty_event (
  penalty_event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  penalty_type text NOT NULL,
  amount numeric(24, 8) NOT NULL DEFAULT 0,
  token_code text NOT NULL REFERENCES billing.token_asset(token_code),
  reason_code text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.refund_record (
  refund_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  amount numeric(24, 8) NOT NULL,
  currency_code text NOT NULL DEFAULT 'CNY',
  status text NOT NULL DEFAULT 'pending',
  executed_by uuid REFERENCES core.user_account(user_id),
  executed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.compensation_record (
  compensation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  amount numeric(24, 8) NOT NULL,
  currency_code text NOT NULL DEFAULT 'CNY',
  status text NOT NULL DEFAULT 'pending',
  executed_by uuid REFERENCES core.user_account(user_id),
  executed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing.invoice_request (
  invoice_request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES trade.order_main(order_id) ON DELETE SET NULL,
  settlement_id uuid REFERENCES billing.settlement_record(settlement_id) ON DELETE SET NULL,
  requester_org_id uuid NOT NULL REFERENCES core.organization(org_id),
  invoice_title text NOT NULL,
  tax_no text,
  amount numeric(24, 8) NOT NULL,
  currency_code text NOT NULL DEFAULT 'CNY',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support.dispute_case (
  case_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  complainant_type text NOT NULL,
  complainant_id uuid NOT NULL,
  reason_code text NOT NULL,
  status text NOT NULL DEFAULT 'opened',
  decision_code text,
  penalty_code text,
  opened_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support.dispute_status_history (
  dispute_status_history_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES support.dispute_case(case_id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  changed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support.evidence_object (
  evidence_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES support.dispute_case(case_id) ON DELETE CASCADE,
  object_type text NOT NULL,
  object_uri text,
  object_hash text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support.decision_record (
  decision_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL UNIQUE REFERENCES support.dispute_case(case_id) ON DELETE CASCADE,
  decision_type text NOT NULL,
  decision_code text NOT NULL,
  liability_type text,
  decision_text text,
  decided_by uuid REFERENCES core.user_account(user_id),
  decided_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS risk.rating_record (
  rating_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES trade.order_main(order_id) ON DELETE CASCADE,
  rater_id uuid,
  target_id uuid,
  score numeric(5, 2) NOT NULL,
  weight numeric(8, 4) NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS risk.reputation_snapshot (
  reputation_snapshot_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  score numeric(10, 4) NOT NULL DEFAULT 0,
  risk_level integer NOT NULL DEFAULT 0,
  credit_level integer NOT NULL DEFAULT 0,
  effective_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS risk.blacklist_entry (
  blacklist_entry_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  reason_code text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  released_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_billing_event_order_id ON billing.billing_event(order_id);
CREATE INDEX IF NOT EXISTS idx_dispute_case_order_id ON support.dispute_case(order_id);
CREATE INDEX IF NOT EXISTS idx_reputation_snapshot_subject ON risk.reputation_snapshot(subject_type, subject_id, effective_at DESC);

CREATE TRIGGER trg_wallet_account_updated_at BEFORE UPDATE ON billing.wallet_account
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_escrow_ledger_updated_at BEFORE UPDATE ON billing.escrow_ledger
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_deposit_record_updated_at BEFORE UPDATE ON billing.deposit_record
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_settlement_record_updated_at BEFORE UPDATE ON billing.settlement_record
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_refund_record_updated_at BEFORE UPDATE ON billing.refund_record
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_compensation_record_updated_at BEFORE UPDATE ON billing.compensation_record
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_invoice_request_updated_at BEFORE UPDATE ON billing.invoice_request
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_dispute_case_updated_at BEFORE UPDATE ON support.dispute_case
FOR EACH ROW EXECUTE FUNCTION common.tg_set_updated_at();
CREATE TRIGGER trg_dispute_status_history AFTER INSERT OR UPDATE ON support.dispute_case
FOR EACH ROW EXECUTE FUNCTION common.tg_dispute_status_history();
