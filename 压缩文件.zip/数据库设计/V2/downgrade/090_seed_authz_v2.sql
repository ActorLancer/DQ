DELETE FROM authz.permission_definition WHERE stage_from = 'V2';
DELETE FROM authz.role_definition WHERE stage_from = 'V2';
