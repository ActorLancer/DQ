DROP TRIGGER IF EXISTS trg_reward_record_updated_at ON billing.reward_record;
DROP TRIGGER IF EXISTS trg_reward_pool_updated_at ON billing.reward_pool;
DROP TRIGGER IF EXISTS trg_profit_share_rule_updated_at ON billing.profit_share_rule;

DROP TABLE IF EXISTS chain.credential_status_history CASCADE;
DROP TABLE IF EXISTS chain.credential_token CASCADE;
DROP TABLE IF EXISTS chain.public_anchor_batch CASCADE;
DROP TABLE IF EXISTS billing.reward_record CASCADE;
DROP TABLE IF EXISTS billing.contribution_record CASCADE;
DROP TABLE IF EXISTS billing.reward_pool CASCADE;
DROP TABLE IF EXISTS billing.profit_share_rule CASCADE;
