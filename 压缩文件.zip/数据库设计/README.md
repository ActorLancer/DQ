# 数据交易平台数据库设计包

## 1. 目标

本目录基于当前工作区全部核心文档生成，覆盖：

- [正式PRD](/home/luna/Documents/DataB/正式PRD)
- [业务流程](/home/luna/Documents/DataB/业务流程)
- [领域模型](/home/luna/Documents/DataB/领域模型)
- [页面说明书](/home/luna/Documents/DataB/页面说明书)
- [权限设计](/home/luna/Documents/DataB/权限设计)
- [用户角色说明](/home/luna/Documents/DataB/用户角色说明)
- [data_trading_blockchain_system_design_split](/home/luna/Documents/DataB/data_trading_blockchain_system_design_split)
- [原始PRD](/home/luna/Documents/DataB/原始PRD)

目标输出：

- 一套面向 PostgreSQL 最新稳定版的全量数据库设计
- 按 `V1 / V2 / V3` 分阶段演进的迁移脚本
- 每个版本同时提供 `upgrade` 和 `downgrade`
- 一份 AI 易于阅读的全量表关系 / ER 文本图
- 一份正式版数据库表字典
- 同时覆盖：
  - 业务数据表
  - 用户/角色/权限数据表
  - 审计与日志数据表
  - 搜索、倒排、向量检索相关表
  - 模型、训练、证明、分润、跨链、监管、生态互联相关表

## 2. 目标数据库版本

- 目标数据库：`PostgreSQL 18.3`
- 依赖扩展：
  - `pgcrypto`
  - `citext`
  - `pg_trgm`
  - `btree_gist`
  - `vector`

说明：

- `vector` 用于向量检索
- PostgreSQL 自带全文检索与 `GIN/GiST` 用于倒排检索
- 大对象、原始密文、模型二进制、证据原文默认放对象存储，数据库只保存元数据、摘要、索引、审计和小型结构化数据

## 3. 目录结构

```text
数据库设计/
  README.md
  数据库设计总说明.md
  表关系总图-ER文本图.md
  数据库表字典正式版.md
  V1/
    upgrade/
    downgrade/
  V2/
    upgrade/
    downgrade/
  V3/
    upgrade/
    downgrade/
```

## 4. 迁移策略

- `V1`：基础身份、商品、订单、交付、账单、争议、审计、搜索、开发者支持
- `V2`：模型、算法、受控计算、联邦协作、证明、分润、公链增强
- `V3`：跨链、图风控、监管穿透、治理冻结、连接器互联、合作伙伴与互认

规则：

- `V2` 默认基于 `V1` 已完成升级
- `V3` 默认基于 `V2` 已完成升级
- 每个升级脚本都有对应降级脚本
- 降级按同版本脚本逆序执行
